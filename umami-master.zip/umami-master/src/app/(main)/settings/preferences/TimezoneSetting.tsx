import { Button, ListItem, Row, Select } from '@umami/react-zen';
import { useState } from 'react';
import { useMessages, useTimezone } from '@/components/hooks';
import { getTimezone } from '@/lib/date';

const timezones = Intl.supportedValuesOf('timeZone');

export function TimezoneSetting() {
  const [search, setSearch] = useState('');
  const { t, labels } = useMessages();
  const { timezone, saveTimezone } = useTimezone();
  const items = search
    ? timezones.filter(n => n.toLowerCase().includes(search.toLowerCase()))
    : timezones;

  const handleReset = () => saveTimezone(getTimezone());

  const handleOpen = isOpen => {
    if (isOpen) {
      setSearch('');
    }
  };

  return (
    <Row gap>
      <Select
        value={timezone}
        onChange={(value: any) => saveTimezone(value)}
        allowSearch={true}
        onSearch={setSearch}
        onOpenChange={handleOpen}
        maxHeight={480}
        buttonProps={{ style: { minWidth: '250px' } }}
      >
        {items.map((item: any) => (
          <ListItem key={item} id={item}>
            {item}
          </ListItem>
        ))}
        {!items.length && <ListItem></ListItem>}
      </Select>
      <Button onPress={handleReset}>{t(labels.reset)}</Button>
    </Row>
  );
}
